.. code:: ipython3

    #importing the required libraries and modules
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns

.. code:: ipython3

    #The dataset file extraction
    df = pd.read_csv('mymoviedb.csv',lineterminator = '\n')

.. code:: ipython3

    df.head(5)




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Release_Date</th>
          <th>Title</th>
          <th>Overview</th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
          <th>Original_Language</th>
          <th>Genre</th>
          <th>Poster_Url</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2021-12-15</td>
          <td>Spider-Man: No Way Home</td>
          <td>Peter Parker is unmasked and no longer able to...</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>8.3</td>
          <td>en</td>
          <td>Action, Adventure, Science Fiction</td>
          <td>https://image.tmdb.org/t/p/original/1g0dhYtq4i...</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2022-03-01</td>
          <td>The Batman</td>
          <td>In his second year of fighting crime, Batman u...</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>8.1</td>
          <td>en</td>
          <td>Crime, Mystery, Thriller</td>
          <td>https://image.tmdb.org/t/p/original/74xTEgt7R3...</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2022-02-25</td>
          <td>No Exit</td>
          <td>Stranded at a rest stop in the mountains durin...</td>
          <td>2618.087</td>
          <td>122</td>
          <td>6.3</td>
          <td>en</td>
          <td>Thriller</td>
          <td>https://image.tmdb.org/t/p/original/vDHsLnOWKl...</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2021-11-24</td>
          <td>Encanto</td>
          <td>The tale of an extraordinary family, the Madri...</td>
          <td>2402.201</td>
          <td>5076</td>
          <td>7.7</td>
          <td>en</td>
          <td>Animation, Comedy, Family, Fantasy</td>
          <td>https://image.tmdb.org/t/p/original/4j0PNHkMr5...</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2021-12-22</td>
          <td>The King's Man</td>
          <td>As a collection of history's worst tyrants and...</td>
          <td>1895.511</td>
          <td>1793</td>
          <td>7.0</td>
          <td>en</td>
          <td>Action, Adventure, Thriller, War</td>
          <td>https://image.tmdb.org/t/p/original/aq4Pwv5Xeu...</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #to display the data information
    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9827 entries, 0 to 9826
    Data columns (total 9 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   Release_Date       9827 non-null   object 
     1   Title              9827 non-null   object 
     2   Overview           9827 non-null   object 
     3   Popularity         9827 non-null   float64
     4   Vote_Count         9827 non-null   int64  
     5   Vote_Average       9827 non-null   float64
     6   Original_Language  9827 non-null   object 
     7   Genre              9827 non-null   object 
     8   Poster_Url         9827 non-null   object 
    dtypes: float64(2), int64(1), object(6)
    memory usage: 691.1+ KB
    

.. code:: ipython3

    df['Genre'].head()




.. parsed-literal::

    0    Action, Adventure, Science Fiction
    1              Crime, Mystery, Thriller
    2                              Thriller
    3    Animation, Comedy, Family, Fantasy
    4      Action, Adventure, Thriller, War
    Name: Genre, dtype: object



.. code:: ipython3

    df.duplicated().sum()




.. parsed-literal::

    0



.. code:: ipython3

    df.describe()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>count</th>
          <td>9827.000000</td>
          <td>9827.000000</td>
          <td>9827.000000</td>
        </tr>
        <tr>
          <th>mean</th>
          <td>40.326088</td>
          <td>1392.805536</td>
          <td>6.439534</td>
        </tr>
        <tr>
          <th>std</th>
          <td>108.873998</td>
          <td>2611.206907</td>
          <td>1.129759</td>
        </tr>
        <tr>
          <th>min</th>
          <td>13.354000</td>
          <td>0.000000</td>
          <td>0.000000</td>
        </tr>
        <tr>
          <th>25%</th>
          <td>16.128500</td>
          <td>146.000000</td>
          <td>5.900000</td>
        </tr>
        <tr>
          <th>50%</th>
          <td>21.199000</td>
          <td>444.000000</td>
          <td>6.500000</td>
        </tr>
        <tr>
          <th>75%</th>
          <td>35.191500</td>
          <td>1376.000000</td>
          <td>7.100000</td>
        </tr>
        <tr>
          <th>max</th>
          <td>5083.954000</td>
          <td>31077.000000</td>
          <td>10.000000</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #To change the release date format 
    df['Release_Date'] = pd.to_datetime(df['Release_Date'])
    print(df['Release_Date'].dtypes)


.. parsed-literal::

    datetime64[ns]
    

.. code:: ipython3

    df['Release_Date'] = df['Release_Date'].dt.year
    df['Release_Date'].dtypes




.. parsed-literal::

    dtype('int32')



.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 9827 entries, 0 to 9826
    Data columns (total 9 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   Release_Date       9827 non-null   int32  
     1   Title              9827 non-null   object 
     2   Overview           9827 non-null   object 
     3   Popularity         9827 non-null   float64
     4   Vote_Count         9827 non-null   int64  
     5   Vote_Average       9827 non-null   float64
     6   Original_Language  9827 non-null   object 
     7   Genre              9827 non-null   object 
     8   Poster_Url         9827 non-null   object 
    dtypes: float64(2), int32(1), int64(1), object(5)
    memory usage: 652.7+ KB
    

.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Release_Date</th>
          <th>Title</th>
          <th>Overview</th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
          <th>Original_Language</th>
          <th>Genre</th>
          <th>Poster_Url</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>Peter Parker is unmasked and no longer able to...</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>8.3</td>
          <td>en</td>
          <td>Action, Adventure, Science Fiction</td>
          <td>https://image.tmdb.org/t/p/original/1g0dhYtq4i...</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2022</td>
          <td>The Batman</td>
          <td>In his second year of fighting crime, Batman u...</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>8.1</td>
          <td>en</td>
          <td>Crime, Mystery, Thriller</td>
          <td>https://image.tmdb.org/t/p/original/74xTEgt7R3...</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2022</td>
          <td>No Exit</td>
          <td>Stranded at a rest stop in the mountains durin...</td>
          <td>2618.087</td>
          <td>122</td>
          <td>6.3</td>
          <td>en</td>
          <td>Thriller</td>
          <td>https://image.tmdb.org/t/p/original/vDHsLnOWKl...</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2021</td>
          <td>Encanto</td>
          <td>The tale of an extraordinary family, the Madri...</td>
          <td>2402.201</td>
          <td>5076</td>
          <td>7.7</td>
          <td>en</td>
          <td>Animation, Comedy, Family, Fantasy</td>
          <td>https://image.tmdb.org/t/p/original/4j0PNHkMr5...</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2021</td>
          <td>The King's Man</td>
          <td>As a collection of history's worst tyrants and...</td>
          <td>1895.511</td>
          <td>1793</td>
          <td>7.0</td>
          <td>en</td>
          <td>Action, Adventure, Thriller, War</td>
          <td>https://image.tmdb.org/t/p/original/aq4Pwv5Xeu...</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #Removingg the unnecessary columns
    cols = ['Overview', 'Original_Language', 'Poster_Url']

.. code:: ipython3

    df.drop(cols, axis=1, inplace = True)
    df.columns




.. parsed-literal::

    Index(['Release_Date', 'Title', 'Popularity', 'Vote_Count', 'Vote_Average',
           'Genre'],
          dtype='object')



.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Release_Date</th>
          <th>Title</th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
          <th>Genre</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>8.3</td>
          <td>Action, Adventure, Science Fiction</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2022</td>
          <td>The Batman</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>8.1</td>
          <td>Crime, Mystery, Thriller</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2022</td>
          <td>No Exit</td>
          <td>2618.087</td>
          <td>122</td>
          <td>6.3</td>
          <td>Thriller</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2021</td>
          <td>Encanto</td>
          <td>2402.201</td>
          <td>5076</td>
          <td>7.7</td>
          <td>Animation, Comedy, Family, Fantasy</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2021</td>
          <td>The King's Man</td>
          <td>1895.511</td>
          <td>1793</td>
          <td>7.0</td>
          <td>Action, Adventure, Thriller, War</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #Creating labels and converting data
    def categorize_data(df, col, labels):
        edges= [df[col].describe()['min'],
                df[col].describe()['25%'],
                df[col].describe()['50%'],
                df[col].describe()['75%'],
                df[col].describe()['max']]
        df[col]=pd.cut(df[col],edges,labels=labels,duplicates='drop')
        return df
                
    

.. code:: ipython3

    labels=['not_popular','below_avg','average','popular']
    categorize_data( df, 'Vote_Average',labels)
    df['Vote_Average'].unique()




.. parsed-literal::

    ['popular', 'below_avg', 'average', 'not_popular', NaN]
    Categories (4, object): ['not_popular' < 'below_avg' < 'average' < 'popular']



.. code:: ipython3

    df['Vote_Average'].value_counts()




.. parsed-literal::

    Vote_Average
    not_popular    2467
    popular        2450
    average        2412
    below_avg      2398
    Name: count, dtype: int64



.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Release_Date</th>
          <th>Title</th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
          <th>Genre</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>popular</td>
          <td>Action, Adventure, Science Fiction</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2022</td>
          <td>The Batman</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>popular</td>
          <td>Crime, Mystery, Thriller</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2022</td>
          <td>No Exit</td>
          <td>2618.087</td>
          <td>122</td>
          <td>below_avg</td>
          <td>Thriller</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2021</td>
          <td>Encanto</td>
          <td>2402.201</td>
          <td>5076</td>
          <td>popular</td>
          <td>Animation, Comedy, Family, Fantasy</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2021</td>
          <td>The King's Man</td>
          <td>1895.511</td>
          <td>1793</td>
          <td>average</td>
          <td>Action, Adventure, Thriller, War</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    #Casting column into category
    df['Genre']=df['Genre'].str.split(', ')
    df=df.explode('Genre').reset_index(drop=True)
    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Release_Date</th>
          <th>Title</th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
          <th>Genre</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>popular</td>
          <td>Action</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>popular</td>
          <td>Adventure</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>popular</td>
          <td>Science Fiction</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2022</td>
          <td>The Batman</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>popular</td>
          <td>Crime</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2022</td>
          <td>The Batman</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>popular</td>
          <td>Mystery</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df['Genre']=df['Genre'].astype('category')
    df['Genre'].dtypes




.. parsed-literal::

    CategoricalDtype(categories=['Action', 'Adventure', 'Animation', 'Comedy', 'Crime',
                      'Documentary', 'Drama', 'Family', 'Fantasy', 'History',
                      'Horror', 'Music', 'Mystery', 'Romance', 'Science Fiction',
                      'TV Movie', 'Thriller', 'War', 'Western'],
    , ordered=False, categories_dtype=object)



.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Release_Date</th>
          <th>Title</th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
          <th>Genre</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>popular</td>
          <td>Action</td>
        </tr>
        <tr>
          <th>1</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>popular</td>
          <td>Adventure</td>
        </tr>
        <tr>
          <th>2</th>
          <td>2021</td>
          <td>Spider-Man: No Way Home</td>
          <td>5083.954</td>
          <td>8940</td>
          <td>popular</td>
          <td>Science Fiction</td>
        </tr>
        <tr>
          <th>3</th>
          <td>2022</td>
          <td>The Batman</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>popular</td>
          <td>Crime</td>
        </tr>
        <tr>
          <th>4</th>
          <td>2022</td>
          <td>The Batman</td>
          <td>3827.658</td>
          <td>1151</td>
          <td>popular</td>
          <td>Mystery</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.info()


.. parsed-literal::

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 25793 entries, 0 to 25792
    Data columns (total 6 columns):
     #   Column        Non-Null Count  Dtype   
    ---  ------        --------------  -----   
     0   Release_Date  25793 non-null  int32   
     1   Title         25793 non-null  object  
     2   Popularity    25793 non-null  float64 
     3   Vote_Count    25793 non-null  int64   
     4   Vote_Average  25552 non-null  category
     5   Genre         25793 non-null  category
    dtypes: category(2), float64(1), int32(1), int64(1), object(1)
    memory usage: 756.7+ KB
    

.. code:: ipython3

    df.nunique()




.. parsed-literal::

    Release_Date     102
    Title           9513
    Popularity      8160
    Vote_Count      3266
    Vote_Average       4
    Genre             19
    dtype: int64



.. code:: ipython3

    sns.set_style('whitegrid')

.. code:: ipython3

    #showing stats on genre column
    df['Genre'].describe()
    sns.catplot(y='Genre' , data= df ,kind='count',order=df['Genre'].value_counts().index,color='#4287f5')
    plt.title('genre')
    plt.show()



.. image:: output_24_0.png


.. code:: ipython3

    #To check popularity
    df[df['Popularity']==df['Popularity'].min()]




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Release_Date</th>
          <th>Title</th>
          <th>Popularity</th>
          <th>Vote_Count</th>
          <th>Vote_Average</th>
          <th>Genre</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>25787</th>
          <td>2021</td>
          <td>The United States vs. Billie Holiday</td>
          <td>13.354</td>
          <td>152</td>
          <td>average</td>
          <td>Music</td>
        </tr>
        <tr>
          <th>25788</th>
          <td>2021</td>
          <td>The United States vs. Billie Holiday</td>
          <td>13.354</td>
          <td>152</td>
          <td>average</td>
          <td>Drama</td>
        </tr>
        <tr>
          <th>25789</th>
          <td>2021</td>
          <td>The United States vs. Billie Holiday</td>
          <td>13.354</td>
          <td>152</td>
          <td>average</td>
          <td>History</td>
        </tr>
        <tr>
          <th>25790</th>
          <td>1984</td>
          <td>Threads</td>
          <td>13.354</td>
          <td>186</td>
          <td>popular</td>
          <td>War</td>
        </tr>
        <tr>
          <th>25791</th>
          <td>1984</td>
          <td>Threads</td>
          <td>13.354</td>
          <td>186</td>
          <td>popular</td>
          <td>Drama</td>
        </tr>
        <tr>
          <th>25792</th>
          <td>1984</td>
          <td>Threads</td>
          <td>13.354</td>
          <td>186</td>
          <td>popular</td>
          <td>Science Fiction</td>
        </tr>
      </tbody>
    </table>
    </div>



